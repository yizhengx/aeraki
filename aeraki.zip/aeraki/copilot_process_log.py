from collections import defaultdict

def count_timestamps(log_file_path):
    timestamp_counts = defaultdict(int)

    with open(log_file_path, 'r') as log_file:
        for line in log_file:
            if 'Counter' in line:
                timestamp = line.split('\t')[0]
                minute_second = ':'.join(timestamp.split(':')[1:3]).split(".")[0]
                timestamp_counts[minute_second] += 1

    for second, count in timestamp_counts.items():
        print(f"{second} {count}")

# Call the function with your log file path
count_timestamps("logs-server-istio")