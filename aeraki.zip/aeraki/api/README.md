This package is deprecated!

Aeraki API has been moved to a standalone reposition: https://github.com/aeraki-mesh/api.
