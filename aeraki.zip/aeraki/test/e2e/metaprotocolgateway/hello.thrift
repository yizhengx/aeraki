namespace java org.aeraki

service HelloService {
  string sayHello(1:required string name)
}
