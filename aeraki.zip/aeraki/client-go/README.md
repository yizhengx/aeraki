This package is deprecated!

Aeraki API client-go has been moved to a standalone reposition: https://github.com/aeraki-mesh/client-go.
