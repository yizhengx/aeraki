import sys

def delete_stats(file_name):
    with open(file_name, "r", encoding="utf-8") as f:
        lines = f.readlines()
    deleted_lines = []
    for i, line in enumerate(lines):
        if "IstioStats" in line:
            deleted_lines = [i-1, i, i+1, i+2]
    with open(file_name, "w", encoding="utf-8") as f:
        for i, line in enumerate(lines):
            if i not in deleted_lines:    
                f.write(line)
    return


if __name__ == "__main__":
    if len(sys.argv) < 2:
        print("Usage: python script.py [argument]")
        sys.exit(1)
    file_name = sys.argv[1]
    print(f"Deleting istio stats for {file_name}")
    delete_stats(file_name)