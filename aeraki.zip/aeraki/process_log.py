
# prev = 0
# with open("logs-server-istio", "r") as f:
#     lines = f.readlines()
#     for line in lines:
#         if "src/meta_protocol_proxy/filters/local_ratelimit/local_ratelimit.cc:55" in line:
#             time = line.split("\t")[3]
#             thread = line.split("\t")[4].strip("\n")
#             if prev != 0:
#                print(int(time)-prev, thread)
#             prev = int(time) 
                
prev = 0
with open("logs-server-istio", "r") as f:
    lines = f.readlines()
    for line in lines:
        if "Counter" in line:
            # time = line.split("\t")[3].split("at")[1]
            time = line.split("\t")[3].split("&&")[1]
            thread = line.split("\t")[4].strip("\n")
            print(time, thread)
            break
            if prev != 0:
               print(int(time)-prev, thread)
            prev = int(time) 
                

